async function checkSubmissionStatus() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const submissionId = document.getElementById("submission-id").value;

  if (!username || !password || !submissionId) {
    alert("입력란을 작성해주세요.");
    return;
  }

  const apiUrl = `http://127.0.0.1:8000/submit`;

  try {
    const response = await axios.get(apiUrl, {
      params: {
        username: username,
        password: password,
        id: submissionId,
      },
      headers: { "Content-Type": "application/json" },
    });

    if (response.status === 200) {
      const submissions = response.data;
      const submission = submissions.find(
        (sub) =>
          sub.id === parseInt(submissionId) &&
          sub.username === username &&
          sub.password === password
      );

      if (submission) {
        displayResult(submission);
      } else {
        alert("제출된 코드를 찾을 수 없습니다.");
      }
    } else {
      alert(`ERROR: ${response.data.message}`);
    }
  } catch (error) {
    handleError(error);
  }
}

// 결과 표시 함수
function displayResult(submission) {
  const resultDiv = document.getElementById("results");
  resultDiv.innerHTML = `<p>Submission ID: ${submission.id}</p>
                           <p>Status: ${submission.status}</p>
                           <p>Created_at: ${new Date(
                             submission.created_at
                           ).toLocaleString()}</p>
                           <p>Updated at: ${new Date(
                             submission.updated_at
                           ).toLocaleString()}</p>`;
  resultDiv.style.display = "block";
}

function handleError(error) {
  if (error.response) {
    alert(`ERROR: ${error.response.data.message}`);
  } else if (error.request) {
    console.error("ERROR:", error.request);
    alert("서버로부터 응답이 없습니다.");
  } else {
    console.error("ERROR:", error.message);
    alert("요청을 처리하는 중에 오류가 발생했습니다.");
  }
}

document
  .getElementById("check-status-btn")
  .addEventListener("click", (event) => {
    event.preventDefault();
    checkSubmissionStatus();
  });
