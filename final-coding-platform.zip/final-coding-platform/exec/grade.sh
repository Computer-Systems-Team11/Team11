CODE_DIR="/project/exec/code"
RESULT_DIR="/project/exec/results"
ANSWER_FILE="/project/exec/answer.txt"

# 디렉토리 내 모든 .py 파일을 순회합니다.
for file in $CODE_DIR/*.py; do
    id=$(basename "$file" .py)

    # 코드를 실행하고 STDOUT과 STDERR를 각각 파일로 저장합니다.
    python3 "$file" > "$RESULT_DIR/$id.stdout" 2> "$RESULT_DIR/$id.stderr"

    # 실행 결과를 확인합니다.
    if [ -s "$RESULT_DIR/$id.stderr" ]; then
        status="ERROR"
    elif diff -q "$RESULT_DIR/$id.stdout" "$ANSWER_FILE"; then
        status="CORRECT"
    else
        status="INCORRECT"
    fi

    # 채점 결과를 관리 서버에 등록합니다.
        curl -X PATCH http://localhost:8000/submission/submission -H "Content-Type: application/json" -d "{\"id\":\"$id\", \"status\":\"$status\"}"
done