MANAGE_SERVER_URL="http://localhost:8000/new"

# 새로운 코드를 관리 서버로부터 요청합니다.
response=$(curl -s $MANAGE_SERVER_URL)

# 응답에서 코드 ID와 코드를 추출합니다.
id=$(echo $response | jq -r '.id')
code=$(echo $response | jq -r '.code')

# 응답이 비어있지 않은지 확인합니다.
if [ "$id" != "null" ]; then
    # 코드를 파일로 저장합니다.
    echo "$code" > ~/project/exec/$id.py
    echo "ID가 $id인 새로운 코드를 성공적으로 가져왔습니다."
else
    echo "새로운 제출물이 없거나 코드를 가져오는 중 오류가 발생했습니다."
fi