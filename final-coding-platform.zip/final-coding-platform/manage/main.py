from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
import datetime
from contextlib import asynccontextmanager
import os
import paramiko  # SFTP 라이브러리

# 데이터베이스 URL 설정 (필요에 따라 경로 변경 가능)
DATABASE_URL = "sqlite:///C:/sqlite3/test.db"

# 데이터베이스 설정
Base = declarative_base()
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Ensure the codes directory exists
if not os.path.exists('codes'):
    os.makedirs('codes')

# 데이터베이스 모델 정의
class Submission(Base):
    __tablename__ = "submission"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    password = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    status = Column(String, default="SUBMITTED")

Base.metadata.create_all(bind=engine)

# Pydantic 모델
class SubmissionCreate(BaseModel):
    username: str
    password: str
    code: str

class SubmissionRead(BaseModel):
    id: int
    username: str
    password: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    status: str

    class Config:
        orm_mode = True

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Application startup")
    yield
    print("Application shutdown")

# FastAPI 애플리케이션 생성
app = FastAPI(lifespan=lifespan)

# CORS 설정 추가
origins = [
    "http://127.0.0.1:5500",  # 클라이언트가 실행되는 주소
    "http://localhost:5500",  # 추가적인 경우
    "http://172.17.76.186:5500"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/submit", status_code=200)
async def create_submission(submission: SubmissionCreate, db: Session = Depends(get_db)):
    if not submission.username or not submission.password or not submission.code:
        raise HTTPException(status_code=400, detail="Missing required fields")

    # 데이터베이스에 제출 저장
    db_submission = Submission(
        username=submission.username,
        password=submission.password
    )
    db.add(db_submission)
    db.commit()
    db.refresh(db_submission)

    # 코드 파일로 저장
    try:
        code_file_path = f"codes/{db_submission.id}.py"
        with open(code_file_path, "w") as code_file:
            code_file.write(submission.code)
        print(f"Code saved at {code_file_path}")
    except Exception as e:
        print(f"Error saving code: {e}")
        raise HTTPException(status_code=500, detail="Error saving code")

    return {"submission_id": db_submission.id}

@app.get("/submissions", response_model=list[SubmissionRead])
async def read_submissions(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    submissions = db.query(Submission).offset(skip).limit(limit).all()
    return submissions

@app.get("/new")
async def get_oldest_submitted_job(db: Session = Depends(get_db)):
    try:
        # 가장 오래된 SUBMITTED 상태의 항목 찾기
        job = db.query(Submission).filter(Submission.status == 'SUBMITTED').order_by(Submission.created_at).first()

        if job is None:
            raise HTTPException(status_code=404, detail="No submitted jobs found")

        # SFTP를 사용하여 코드 파일 전송
        sftp_host = 'your_sftp_server'
        sftp_port = 22
        sftp_username = 'your_username'
        sftp_password = 'your_password'
        local_file_path = f"codes/{job.id}.py"
        remote_file_path = f'/remote/path/{job.id}.py'

        try:
            transport = paramiko.Transport((sftp_host, sftp_port))
            transport.connect(username=sftp_username, password=sftp_password)
            sftp = paramiko.SFTPClient.from_transport(transport)
            sftp.put(local_file_path, remote_file_path)
            sftp.close()
            transport.close()
        except Exception as e:
            print(f"SFTP error: {e}")
            raise HTTPException(status_code=500, detail="Failed to transfer file via SFTP")

        # 상태를 PROCESSING으로 업데이트하고 updated_at를 현재시각으로 설정
        job.status = 'PROCESSING'
        job.updated_at = datetime.datetime.utcnow()
        db.commit()

        return {"message": "Job is now processing"}

    except Exception as e:
        print(f"Error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.exception_handler(404)
async def custom_404_handler(request: Request, exc: HTTPException):
    return {"error": "Not Found"}

@app.exception_handler(500)
async def custom_500_handler(request: Request, exc: HTTPException):
    return {"error": "Internal Server Error"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="debug")
